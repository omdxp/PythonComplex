# PythonComplex
Complex class for different operations on complex numbers.

## More details
- This class is essentially for mathematical operations on complex numbers.
- It is very easy and intuitif to use, as any mathematicain would expect.
- There is more to come on this class, like power of complex numbers.
